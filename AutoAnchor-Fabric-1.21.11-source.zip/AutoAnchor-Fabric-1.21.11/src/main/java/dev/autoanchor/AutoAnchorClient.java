package dev.autoanchor;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/**
 * AutoAnchor prototype for Fabric 1.21.11.
 * Uses normal client interactions. It deliberately aborts rather than activate
 * an anchor when it cannot verify a cover placement.
 */
public final class AutoAnchorClient implements ClientModInitializer {
    private static KeyBinding activateKey;
    private static int phase;
    private static int ticksLeft;
    private static int originalSlot = -1;
    private static BlockPos anchorPos;
    private static boolean running;

    @Override
    public void onInitializeClient() {
        activateKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.autoanchor.activate", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_T,
                KeyBinding.Category.GAMEPLAY));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null || client.interactionManager == null) {
                reset(client, false);
                return;
            }
            while (activateKey.wasPressed()) {
                if (running) reset(client, true);
                else begin(client);
            }
            if (!running) return;
            if (--ticksLeft < 0) {
                abort(client, "Timed out; this attempt has been forgotten.");
                return;
            }
            switch (phase) {
                case 1 -> placeAnchor(client);
                case 2 -> chargeAnchorOnce(client);
                case 3 -> attemptCover(client);
                default -> abort(client, "Invalid sequence; cancelled.");
            }
        });
    }

    private static void begin(MinecraftClient client) {
        if (!(client.crosshairTarget instanceof BlockHitResult hit)) {
            message(client, "Aim at a block first."); return;
        }
        if (findItem(client, Items.RESPAWN_ANCHOR) < 0 || findItem(client, Items.GLOWSTONE) < 0) {
            message(client, "Need a respawn anchor and glowstone in your hotbar."); return;
        }
        originalSlot = client.player.getInventory().getSelectedSlot();
        anchorPos = hit.getBlockPos().offset(hit.getSide());
        phase = 1;
        ticksLeft = 20; // 20 ticks ~= 1 second; server lag can make this take longer.
        running = true;
    }

    private static void placeAnchor(MinecraftClient client) {
        if (!(client.crosshairTarget instanceof BlockHitResult hit)) {
            abort(client, "No valid placement target."); return;
        }
        int slot = findItem(client, Items.RESPAWN_ANCHOR);
        if (slot < 0) { abort(client, "Anchor missing; cancelled."); return; }
        client.player.getInventory().setSelectedSlot(slot);
        client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, hit);
        phase = 2;
    }

    private static void chargeAnchorOnce(MinecraftClient client) {
        if (anchorPos == null || !client.world.getBlockState(anchorPos).isOf(Blocks.RESPAWN_ANCHOR)) {
            abort(client, "Anchor placement not confirmed; attempt forgotten."); return;
        }
        int slot = findItem(client, Items.GLOWSTONE);
        if (slot < 0) { abort(client, "Glowstone missing; cancelled."); return; }
        client.player.getInventory().setSelectedSlot(slot);
        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(anchorPos), Direction.UP, anchorPos, false);
        client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, hit);
        phase = 3;
    }

    private static void attemptCover(MinecraftClient client) {
        /*
         * Glowstone is not blast-resistant enough to be dependable protection.
         * A cover block can also obstruct line-of-sight to the anchor. Do not
         * guess a position or activate anyway: cancel and clear all pending state.
         */
        abort(client, "Safety cover cannot be verified. Activation cancelled; anchor forgotten.");
    }

    private static int findItem(MinecraftClient client, Item item) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = client.player.getInventory().getStack(i);
            if (stack.isOf(item)) return i;
        }
        return -1;
    }

    private static void message(MinecraftClient client, String value) {
        if (client.player != null) client.player.sendMessage(Text.literal("AutoAnchor: " + value), true);
    }

    private static void abort(MinecraftClient client, String reason) {
        message(client, reason);
        reset(client, true);
    }

    private static void reset(MinecraftClient client, boolean restoreSlot) {
        if (restoreSlot && client.player != null && originalSlot >= 0 && originalSlot < 9)
            client.player.getInventory().setSelectedSlot(originalSlot);
        phase = 0;
        ticksLeft = 0;
        originalSlot = -1;
        anchorPos = null;
        running = false;
    }
}
