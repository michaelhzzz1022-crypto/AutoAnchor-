# AutoAnchor — Fabric 1.21.11

This is a **source project**, not a compiled `.jar` yet.

## Current prototype behavior
- Registers `T` as the activation key.
- Checks for a targeted block and a respawn anchor + glowstone in the hotbar.
- Attempts to place an anchor and interact with it once using glowstone.
- Uses a 20-client-tick timeout (about one second when the game is running normally).
- Cancels by clearing the saved anchor position and all pending sequence state, and restores the previous hotbar slot.

## Important limitation
Automatic cover placement and activation are intentionally not implemented in this prototype. Glowstone is not reliable blast protection, and placing a block between the player and anchor can obstruct the interaction. The mod therefore aborts rather than activating an anchor without verified cover. A one-second duration cannot be guaranteed because server latency and placement delays vary.

## Build into a `.jar`
Requires Java 21 and internet access to download Gradle/Fabric dependencies.

1. Install IntelliJ IDEA Community Edition.
2. Extract this ZIP.
3. In IntelliJ, choose **Open** and select the extracted `AutoAnchor-Fabric-1.21.11` folder.
4. Allow it to import/sync the Gradle project and download dependencies.
5. Open the Gradle tool window, then **Tasks → build → build**.
6. The compiled mod should appear in `build/libs/autoanchor-1.0.0.jar`.

If Gradle says a configured Fabric/Yarn version cannot be found, update the corresponding version in `gradle.properties` to a published Minecraft 1.21.11 version. This project has not been compiled or tested in this environment.
